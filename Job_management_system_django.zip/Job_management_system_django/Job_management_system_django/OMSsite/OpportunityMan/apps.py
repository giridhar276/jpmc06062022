from django.apps import AppConfig


class OpportunitymanConfig(AppConfig):
    name = 'OpportunityMan'
