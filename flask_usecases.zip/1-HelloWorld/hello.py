from flask import Flask
app = Flask(__name__)
 
@app.route("/")
def hello():
    return "Hello World!"
 
@app.route("/info")
def hello1():
    return "this is info page"    

@app.route("/clients")
def hello2():
    return "this is clients page"    


@app.route("/data")
def hello3():
    return "this is data page"    
    


if __name__ == "__main__":
    app.run()
