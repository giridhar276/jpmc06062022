# traditional way
# legacy way
# opening in write mode
fobj = open("customers.txt","w")
# writing to the file
fobj.write("amazon\n")
fobj.write("flipkart\n")
fobj.write('walmart\n')
# close
fobj.close()


# pythonic way
# context manager
# if any line starts with keyword with ... it is called as context manager
# Advantage : file will be closed automatically
with open("customers1.txt","w") as fobj:
    # writing to the file
    fobj.write("amazon\n")
    fobj.write("flipkart\n")
    fobj.write('walmart\n')

    # file will be closed automatically when you hit backspace

    


