

import os
import shutil

source = r"D:\trainings\jpmc06062022\programs\source"
destination = r"D:\trainings\jpmc06062022\programs\destination"

cwd= os.getcwd()

os.chdir(source)
for file in os.listdir(source):
    #shutil.copy(file,destination)
    if os.path.exists(destination + "\\" + file):
        print(file,"already exists in",destination)
    else:
        shutil.copy(file,destination)
        print(file,"copied to",destination)

