
'''
create two folders as below and few common files in both the folders
C:\python36
C:\python27


Write a Python to compare 2 directories ( Eg: C:\python36 and c:\python27 ) and display the below information

-all the common files present in C:\python36 and C:\python27
-all the distinct files present in both C:\python36 and C:\python27
-all the files present in C:\python36
-all the files present in C:\python27
'''


from filecmp import dircmp

# Construct a new directory comparision object
# to compare the directories left and right

dcmp = dircmp(r"C:\Python27",r"C:\Python36")

# This directory from left side of dircmp method
print("\nleft:",dcmp.left)



#Files and subdirectories in a directory from left side of dircmp method
print("\nleft list:", dcmp.left_list)

#The directory from right side of dircmp method
print("\nright:",dcmp.right)

 
#Files and subdirectories in a directory from right side of dircmp method
print("\right list:", dcmp.right_list)

#Files and subdirectories in both left and right
print("\nCommon:",dcmp.common)

#Files in both left and right
print("\nCommon files:", dcmp.common_files)

#files which are identical in both left and right, using the class's
# file comparision operator
print("\nsame_files", dcmp.same_files)
