# -*- coding: utf-8 -*-
"""
write a program to replace the lines containing

SACRAMENTO  with HYDERABAD
RIO LINDA  with BANGALORE

and write the output to 07_Jun_2022.csv
"""



import csv
import time

filename = time.strftime("%d_%b_%Y.csv")
print(filename)
citylist = list()
with open("realestate.csv","r") as fobj:
    with open(filename,"w") as fw:
        for line in fobj:
            line = line.strip()
            line = line.replace('SACRAMENTO','HYDERABAD')
            line = line.replace('RIO LINDA','BANGALORE')
            fw.write(line + "\n")
        



import pandas
df = pandas.read_csv('realestate.csv')

df.replace(to_replace ="SACRAMENTO", value ="Hyderabad", inplace=True)
df.replace(to_replace ="RIO LINDA", value ="Bengaluru", inplace=True)
print(df)