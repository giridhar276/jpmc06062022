import socket

def get_remote_machine_info(remote):
    
    try:
        print("IP address: {}".format(socket.gethostbyname(remote)))
    except socket.error as err_msg:
        print("{}: {}".format(remote, err_msg))



with open("hostnames.txt","r") as fobj:
    for host in fobj:
        host = host.strip()
        get_remote_machine_info(host)




import socket
import time
def get_remote_machine_info(remote):
    
    try:
        filename = time.strftime("host_%d_%b_%Y.csv")
        with open(filename,"a") as fw:
            host = remote
            ipaddress = socket.gethostbyname(remote)
            #print("IP address: {}".format(socket.gethostbyname(remote)))
            fw.write(",".join([host,ipaddress]) + "\n")
    except socket.error as err_msg:
        print("{}: {}".format(remote, err_msg))



with open("hostnames.txt","r") as fobj:
    for host in fobj:
        host = host.strip()
        get_remote_machine_info(host)








from openpyxl import Workbook
import socket
import time
wb = Workbook()

# grab the active worksheet
ws = wb.active
filename = time.strftime("host_%d_%b_%Y.xlsx")
def get_remote_machine_info(remote):
    
    try:
        host = remote
        ipaddress = socket.gethostbyname(remote)
        ws.append([host, ipaddress])    
    except socket.error as err_msg:
        print("{}: {}".format(remote, err_msg))



with open("hostnames.txt","r") as fobj:
    for host in fobj:
        host = host.strip()
        get_remote_machine_info(host)


wb.save(filename)





### using csv
from openpyxl import Workbook
import socket
import time
import csv
wb = Workbook()

# grab the active worksheet
ws = wb.active
filename = time.strftime("host_%d_%b_%Y.xlsx")
def get_remote_machine_info(remote):
    
    try:
        host = remote
        ipaddress = socket.gethostbyname(remote)
        ws.append([host, ipaddress])    
    except socket.error as err_msg:
        print("{}: {}".format(remote, err_msg))



with open("hostnames.txt","r") as fobj:
    # convrting file object to csv object
    reader = csv.reader(fobj)
    for host in reader:
        host = host[0]
        get_remote_machine_info(host)


wb.save(filename)















