'''
Write a Python program to display the below information.

display the current user name
display current working directory
display Operating system name
display process id of your running program
display the current timestamp
display yesterday’s date
display tomorrow’s date
display all the environment variables that are existing
display the python executable path ( just like ‘which python3’ in Linux )
'''

import os
import time
import datetime
import sys
import platform
try:
    print(os.getlogin())
    print(os.getcwd())
    print(platform.platform())
    print(platform.node())
    print(os.getpid())
    print(datetime.datetime.now())
    today = datetime.date.today()
    print('Today:', today)
    yesterday = today - datetime.timedelta(days=1)
    print('Yesterday:', yesterday)
    tomorrow = today + datetime.timedelta(days=1)
    print('Tomorrow:', tomorrow)
    print(os.environ)
    print(sys.executable)
except Exception as err:
    print(err)
    print(sys.exc_info())
    