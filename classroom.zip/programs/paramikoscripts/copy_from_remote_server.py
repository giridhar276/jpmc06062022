import paramiko
	
host = '192.168.19.131'
port = 22
username = 'user'
password = 'password'
	
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(hostname=host,  username=username, password = 'password')
sftp = ssh.open_sftp()

remote_path = '/home/user/Desktop/ftpfiles/'
remote_command = "ls " + remote_path
stdin,stdout,stderr = ssh.exec_command(remote_command )

local_path = '/tmp/'

for file in stdout.read().splitlines():
    file  = file.decode('utf-8')
    #print(file)
    file_remote = remote_path + file
    file_local = local_path + file
    print(file_remote + '  >>>  ' + file_local)
    sftp.get(file_remote, file_local)

ssh.close()
sftp.close()

