

# current working directory
with open("customers1.txt","w") as fobj:
    # writing to the file
    fobj.write("amazon\n")
    fobj.write("flipkart\n")
    fobj.write('walmart\n')



#with open("D:/new/new/customers1.txt","w") as fobj:
#with open(r"D:\new\new\customers1.txt","w") as fobj:  # r--> raw string
with open("D:\\new\\new\\customers1.txt","w") as fobj:
    # writing to the file
    fobj.write("amazon\n")
    fobj.write("flipkart\n")
    fobj.write('walmart\n')
    
    
    
    
with open("numbers.txt","w") as fobj:
    # writing to the file
    for val in range(1,10):
        fobj.write(str(val) + "\n")
        
        