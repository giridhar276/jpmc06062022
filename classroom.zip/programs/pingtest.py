
import pdb
pdb.set_trace()
import subprocess
import shlex

command = "ping www.gooadsfafdsafsgle.com"
args = shlex.split(command)
print(args)

try:
    subprocess.check_call(args, stdout = subprocess.PIPE , stderr = subprocess.PIPE)
    print("site is up")
    
except subprocess.CalledProcessError:
    print("failed to ping")