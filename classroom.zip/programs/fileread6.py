
import json


with open("employee_multiple1.json","r") as fobj:
    # converting file object to the dictionary using library
    data = json.load(fobj)
    for item in data['users']:
        values =list(item.values())
        # typecasting value at index 0 to string
        ##values[0] = str(values[0])
        values = list(map(lambda x:str(x),values))
        line = ",".join(values)
        #print(line)
    
