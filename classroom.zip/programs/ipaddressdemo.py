
# check for valid IP
import ipaddress
output =ipaddress.ip_address('199.138.0.123')
print(output)



#Looping Through Networks
net = ipaddress.IPv4Network("192.4.2.0/28")
for addr in net:
    print(addr)


#check for  valid IPv6 Address?
#IPv6 validates values from range 0 to ffff. An integer that fits into 128 bits. An integer packed into a byte object which is of length 16.

import ipaddress
output = ipaddress.ip_address('2011:cb0::')
print(output)
output = ipaddress.ip_address('FFFF:9999:2:FDE:257:0:2FAE:112D')
print(output)




## IP functions
import ipaddress
 
ipa = ipaddress.ip_address('199.138.0.1')
print(ipa.is_private) # Checks if address is private
print(ipa.is_global)  # Checks if address is global
 
#If address is a loopback address
print(ipaddress.ip_address("127.0.0.1").is_loopback) 
 
#If address is reserved for multiclass use
print(ipaddress.ip_address("229.100.0.23").is_multicast) 
 
#If address is reserved for link local usage
print(ipaddress.ip_address("169.254.0.100").is_link_local)
 
#True if the address is otherwise IETF reserved.
print(ipaddress.ip_address("240.10.0.1").is_reserved)




'''
Reverse IP Lookups
The reverse pointer function requests the DNS 
to resolve the IP address added as an argument here. If the DNS is able to resolve the IP, you’ll receive an output with the name assigned.

If you ping an IP that’s assigned to a domain name, you’ll likely get the name of the server on which the domain exists. However this can change depending on the firewall setup.
'''

print(ipaddress.ip_address("199.138.0.1").reverse_pointer)





net = ipaddress.IPv4Network("200.100.10.0/24")
for sn in net.subnets():
    print(sn)


#You can also tell .subnets() what 
#the new prefix should be. 
#A higher prefix means more and smaller subnets:
for sn in net.subnets(new_prefix=28):
    print(sn)


#Working with IP Networks using the ipaddress module
#An IPv4Network and IPv6Network can hlep us
# define and inspect IP network definitions.

ipn = ipaddress.ip_network("10.0.0.0/16")
print(ipn.with_prefixlen)
print(ipn.with_hostmask)
print(ipn.with_netmask)




#1. Check if an IP address is IPv4 or IPv6

import ipaddress
ipaddress.ip_network('199.138.0.1')
ipaddress.ip_network('FFFF:9999:2:FDE:257:0:2FAE:112D')



# Identify hosts on an IP network
#Hosts are all the IP addresses that belong to a network except the network address and network broadcast address.

ipn= ipaddress.ip_network('192.0.2.0/29')
print(list(ipn.hosts()))




# Identifying the broadcast address for networks

ipn= ipaddress.ip_network('199.1.8.0/29')
print(ipn.broadcast_address)



# Identifying IP network overlaps
ipn1 = ipaddress.ip_network("10.10.1.32/29")
ipn2 = ipaddress.ip_network("10.10.1.32/27")
ipn3 = ipaddress.ip_network("10.10.1.48/29")
print(ipn1.overlaps(ipn2))
print(ipn1.overlaps(ipn3))
print(ipn3.overlaps(ipn2))



#Subnets on IP networks

ipn1 = ipaddress.ip_network("10.10.1.32/29")
print(list(ipn1.subnets()))
print(list(ipn1.subnets(prefixlen_diff=2)))
print(list(ipn1.subnets(new_prefix=30))) 


#Creating supernets with the ipaddress module
ipnn = ipaddress.ip_network("172.10.15.160/29")
print(ipnn.supernet(prefixlen_diff=3))
print(ipnn.supernet(new_prefix=20))



#Check if an IP network is a supernet/subnet of another IP network
#Returns true is a network is subnet of the other of if a network is supernet of the other. Returns either true or false.

a = ipaddress.ip_network("192.168.1.0/24")
b = ipaddress.ip_network("192.168.1.128/30")
 
print(b.subnet_of(a))
print(a.supernet_of(b))



'''
Working with IPv4Interface objects
Interface objects can be used as keys in dictionaries as they are hashable.

IPv4Interface inherits all the attributes from IPv4Address as IPv4Interface is the subclass of IPv4Address.

Here, 199.167.1.6 IP address is in the network 199.167.1.0/24
'''
from ipaddress import IPv4Interface
ifc = IPv4Interface("199.167.1.6/24")
print(ifc.ip)
print(ifc.network)



ipa1=ipaddress.ip_address("127.0.0.2")
ipa2=ipaddress.ip_address("127.0.0.1")
print(ipa1>ipa2)
print(ipa1==ipa2)
print(ipa1!=ipa2)












