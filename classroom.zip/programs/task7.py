
'''
Write a Python program to display the below information.
– disk utilization of C:\ ( total , used and free space)
– disk utilization of \tmp ( if using linux)
– display CPU utilization
– display Memory utilization

'''

import psutil
import os
import shutil
import sys
try:
    print(shutil.disk_usage("D:\\"))
    print(psutil.cpu_percent())
    print(psutil.virtual_memory())
    # you can convert that object to a dictionary 
    dict(psutil.virtual_memory()._asdict())
except Exception as err:
    print(err)
    print(sys.exc_info())