




import pymysql
import os
import csv

try:
    count = 0
    #step1
    # db is just like connection hand
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123')
    if db:
        print("connection successful")
    cursor = db.cursor()
    filename = "realestate.csv"
    if os.path.isfile(filename) and os.path.getsize(filename) > 0:
        with open(filename) as fr:
            reader = csv.reader(fr)
            for line in reader:
                street = line[0]
                city = line[1]                
                query = "insert into jpmc.realestate values('{}','{}')".format(street,city)
                #print(query)
                cursor.execute(query)
                count = count + 1
                #print(cursor.rowcount,"row inserted")
        db.commit()
        print(count,"rows inserted")
    else:
        print("file not found")
    #step5
    db.close()
    
    
except Exception as err:
    print(err)
    
    