
import pymysql

try:
    #step1
    # db is just like connection hand
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123')
    if db:
        print("connection successful")
    cursor = db.cursor()
    #step2
    query = "select * from jpmc.realestate"
    #step3
    cursor.execute(query)
    #step4
    for record in cursor.fetchall():
        print("Street :",record[0])
        print("City   :",record[1])
    #step5
    db.close()
    
    
except Exception as err:
    print(err)
    