
'''
Write a Python program to display ONLY .py files and its size as below from the current directory with proper formatting.

Sample output:
update_customer.py   108 bytes
customer_info.py      45 bytes
remote_server.py      49 bytes
'''




import os
import sys
import re
cwd = os.getcwd()
print("-----------------")
print(cwd)
print("-----------------")
try:
    files = os.listdir()
    for file in files:
        size = os.path.getsize(file)
        print(file.ljust(20), size,"bytes")
except Exception as err:
    print(err)