

from getpass import getpass

password = getpass()
print("Your password :", password)