


import os
for val in range(1,11):
    dirname = "dir" + str(val)
    os.mkdir(dirname)
    
    
    
import os
for val in range(1,11):
    dirname = "dir" + str(val)
    os.rmdir(dirname)    
    
    
