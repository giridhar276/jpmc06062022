
import os
import sys

cwd = os.getcwd()
print("-----------------")
print(cwd)
print("-----------------")
try:
    files = os.listdir()
    for file in files:
        print(file)
except Exception as err:
    print(err)
    print(sys.exc_info())
    
    
    
import os
import sys

cwd = os.getcwd()
print("-----------------")
print(cwd)
print("-----------------")
try:
    files = os.listdir("C:\\")
    for file in files:
        print(file)
except Exception as err:
    print(err)
    print(sys.exc_info())
    
        
    

import glob

files = glob.glob(r"D:\trainings\jpmc06062022\programs\*.csv")
#print(files)
for file in files:
    print(file)


