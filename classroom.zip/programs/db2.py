


import pymysql


try:
    #step1
    # db is just like connection hand
    db = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123')
    if db:
        print("connection successful")
    cursor = db.cursor()
    #step2
    query = "insert into jpmc.realestate values('{}','{}')".format('Brigade Road','Bangalore')
    #print(query)
    cursor.execute(query)
    print(cursor.rowcount,"row inserted")
    db.commit()

    #step5
    db.close()
    
    
except Exception as err:
    print(err)
    