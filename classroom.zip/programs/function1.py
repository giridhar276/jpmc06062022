### fixed arguments
# function body
def display(a,b):
    print(a,b)


# calling function
display(10,20)





# fixed arguments


def display(a,b):
    c = a +b
    print(c)



display(10,20)

##
#
#
#









