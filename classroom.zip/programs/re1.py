


with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if "python programming" in line or "pyttttthon programming" in line or 'pytttttthon programming' in line:
            print(line)
        
        
        
### using re library      

import re
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("[a-zA-Z]ython",line):
            # mython or yython or qython or python
            print(line)
                
            
 