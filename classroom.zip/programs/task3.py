filename = "ab.py.txt"

import os
import sys
import re
cwd = os.getcwd()
print("-----------------")
print(cwd)
print("-----------------")
try:
    files = os.listdir()
    for file in files:
        if re.search(".py$",file):
            print(file)
except Exception as err:
    print(err)
    print(sys.exc_info())
    

