# explicitly
alist = [10,20,30,40,50]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)




alist = [10,20,30,40,50]
# method1
def increment(x):
    return x + 5
# map(function,iterable)
print(list(map(increment,alist)))


#method2
increment = lambda x : x+5
# map(function,iterable)
print(list(map(increment,alist)))

#method3
# map(function,iterable)
print(list(map(lambda x : x+5,alist)))




# explicity
alist = [10,20,30,40,50]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)


for val in alist:
    print(val+5)


def alist(*args):
    for i in args:
        print(i+5, end=",")
        
alist(10,20,30,40,50)



alist = ['1','2','3','4']

print(list(map(lambda x: int(x), alist)))
#[1,2,3,4]




blist = []
for val in alist:
    blist.append(int(val))
print(blist)




domains = ["google","facebook","linked"]

#["www.google.com","www.facebook.com","www.linkedin.com"]
print(list(map(lambda x: "www." + x + ".com", domains)))
















