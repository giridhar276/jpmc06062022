




name= "python programming"

name[0] = "z"

print(name)


print(name.capitalize())
print(name.title())

# get the count
print(name.count("p"))

#replace
print(name.replace("python","ruby"))

# to make the changes permanent
#name = name.replace("python","ruby")

#find - check for substring
print(name.find("prog"))

#split(deli)
print(name.split(" "))

#center()
print(name.center(30))
print(name.center(30,"*"))


print(name.startswith("py"))

print(name.endswith("ing"))

print(name.isupper())


print(name.islower())


a =100
b = 20
if a < b:
    print("A is less than B")
    print("inside if")
    print("Still inside if")
else:
    print("A is greater than B")
    print("inside else")
    print("still inside else")





aname = "python"
if aname.startswith("py"):
    print("its python")
    print("inside if")
elif aname.startswith("pl"):
    print("its perl")
    print("inside elif")
elif aname.startswith("sh"):
    print("its shell")
    print("inside elif")
else:
    print("its someother language")
    print("inside else")


aname = "I love {} and {}"
print(aname.format("python","shell"))
print(aname.format("java","oracle"))


aname = "I love {0} and {2}"
print(aname.format("python","shell","c"))
print(aname.format("java","oracle","oracle"))


aname = "I love {1} and {0}"
print(aname.format("python","shell"))
print(aname.format("java","oracle"))


string = "hostnames are { }.com and {}.in"

print(string.format("google","flipkart"))
print(string.format("edge","amazon"))


aname = " python  "
print(len(aname))
print(len(aname.strip()))
print(len(aname.rstrip()))
print(len(aname.lstrip()))


# convert list to string    
alist = ["python","java","spark"]
string = ",".join(alist)
print(string)
    
    
    




# display all the values fro 1 to 10
for val in range(1,11):
    print(val)


    
name = "python programming"

for char in name:
    print(char)
















    
    









