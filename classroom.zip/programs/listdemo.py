

alist = [34,56,12,23,554,32,76]

#slicing
print(alist[0:4])
print(alist[::-1])

## methods

# list.append(value)
alist.append(93)
print("after appending :",alist)

alist.append(51)
print("after appending :",alist)

# add multiple values
alist.extend([27,81,73])
print('after extending :',alist)


# alist.insert(index,position)
alist.insert(1,198)
print('After inserting :',alist)
alist.insert(4,72)
print('After inserting :',alist)


# deleting
alist.pop(1)  # 1 is the index  # vbe remoed
print('After pop :',alist)

alist.pop()     #last value will be removed
print('After pop :',alist)


alist.remove(12)  # 12 will be removed from the list if existing
print('After removing :',alist)

alist.remove(100)
print('After removing :',alist)


if 100 in alist:
    print(100,"exists")
else:
    print("100","doesnt exist")
    
    
if 100 in alist:
    alist.remove(100)
else:
    print("100","doesnt exist")    
    
    
name = "python programming"
print(name.find("prog"))
if name.find("prog") != -1 :
    print("exists")
else:
    print("doesnt exist")


if "prog" in name:
    print("exists")
else:
    print("doesnt exist")




## alist.reverse()
print(alist)
print(alist[::-1])

alist.reverse()
print('After reversing :', alist)


## alist.sort()
alist.sort()     # ascending order
print('after sorting' ,alist)


alist.sort(reverse = True)
print('reverse sorted order :',alist)





# iterating list

alist = [30,12,40,34]
for val in alist:
    print(val)


for val in alist[3:]:
    print(val)






