
# all the methods will be imported to your program space
import math
print(math.tan(2))
print(math.log(1))



#method2
import math as m
print(m.floor(23.3))
print(m.ceil(87.1))
print(m.log(3))


#method3
# . is not required in this case
from math import tan,sin,log
print(tan(3))
print(log(1))


# method4
# . is not required in this case
from math import *
print(tan(3))
print(log(1))

