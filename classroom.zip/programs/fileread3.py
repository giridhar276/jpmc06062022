
## using set
import csv
cityset = set()
with open("realestate1111.csv","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        # each line will be in the list format
        city = line[1]
        cityset.add((city))
    # display the output    
    for city in cityset:
        print(city)
        

        

# using dictionary
import csv
citydict = dict()
with open("realestate.csv","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        # each line will be in the list format
        city = line[1]
        citydict[city] = 1
    # display the output    
    for city in citydict.keys():
        print(city)



# using list
import csv
citylist = list()
with open("realestate.csv","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        # each line will be in the list format
        city = line[1]
        citylist.append(city)
    # display the output    
    for city in set(citylist):
        print(city)




# using list and condition
import csv
citylist = list()
with open("realestate.csv","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        # each line will be in the list format
        city = line[1]
        if city not in citylist:
            citylist.append(city)
    # display the output    
    for city in citylist:
        print(city)










