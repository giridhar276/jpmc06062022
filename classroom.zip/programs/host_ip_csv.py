

### using csv

import socket
import time
import csv

def get_remote_machine_info(remote):
    
    try:
        filename = time.strftime("host_%d_%b_%Y_new.csv")
        with open(filename,"a") as fw:
            writer = csv.writer(fw)
            host = remote
            ipaddress = socket.gethostbyname(remote)
            writer.writerow([host,ipaddress])
            
    except socket.error as err_msg:
        print("{}: {}".format(remote, err_msg))



with open("hostnames.txt","r") as fobj:
    for host in fobj:
        host = host.strip()
        get_remote_machine_info(host)
