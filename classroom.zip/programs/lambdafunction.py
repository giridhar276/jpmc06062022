
# everything runs on OS platform is a process
# Every process contains set of system calls internally

# function body
def display(a,b):
    c = a +b
    return c

total = display(10,20)
print(total)


# lambda function ( inline function ,  ananymous function )
# lambda is the replacement of the single liner function
# instead of writing the function as above, we simply define lambda function
# syntax
# function = lambda variables :expression
# Advantage of using lambda : we will not have any system calls internally
# the function body will be replaced with the function body
# faster in performance

# syntax
# function = lambda variables :expression


display = lambda a,b : a+b
total = display(10,20)
print(total)




