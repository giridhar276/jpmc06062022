
import os


filedict = dict()
for file in os.listdir():
    if os.path.isfile(file):
        filename = file.split(".")[0]
        extension = file.split(".")[1]
        filedict[extension] = filename
        
        
filextension = input("Enter any extension :")
if filextension in filedict:
    print(filedict[filextension])
else:
    print("its not found")