


# list
alist = [10,20,30,40]
alist[0] = 1000
alist[1] = 2000
print('After replacing :',alist)





# tuple
atup = (10,20,30,40)
atup[0] = 1000
print('After replacing :', atup)



# typecasting : covverting from one object to another object

atup = (10,20,30,40)
# converting tuple to list
alist = list(atup)
# making required changes
alist.append(43)
# reconverting back to tuple
atup = tuple(alist)
print('After replacing :', atup)




## list of lists
empdata = [['ram','lname,','middlename','1-1-1'],['rao','lname,','middlename','2-2-2']]


# list of tuples
empdata = [('ram','lname,','middlename','1-1-1'),('rao','lname,','middlename','2-2-2')]


















