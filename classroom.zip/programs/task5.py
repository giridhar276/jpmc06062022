
'''
Write a Python program to display all the files and folders separately and its count also.

files
------
file1
file2
file3

Total no. of files : 504

directories
------------
dir1
dir2
dir3

Total no. of direcotires : 453
'''
import os
filelist = []
dirlist = []
for file in os.listdir():
    if os.path.isfile(file):
        filelist.append(file)
    else:
        dirlist.append(file)
        
## display
print("**** Files ****")
for file in filelist:
    print(file)
print("total no. of files",len(filelist))
print("***** Directories ****")
for file in dirlist:
    print(file)