


aset = {10,10,20,20,30,30,30,30,30,30}
print(aset)


aset.add(10)

print(aset)


aset.add(100)
print(aset)