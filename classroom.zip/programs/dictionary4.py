
ytag = {
  "kind": "youtube#searchListResponse",
  "etag": "1m2yskBQFythfE4irbTIeOgYYfBU1",
  "nextPageToken": "CAUQAA",
  "regionCode": "KE",
  "pageInfo": {
    "totalResults": 4249,
    "resultsPerPage": 5
  },
  "items": [
    {
      "kind": "youtube#searchResult",
      "etag": "2m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#channel",
        "channelId": "UCJowOS1R0FnhipXVqEnYU1A"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "3m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#video",
        "videoId": "Eqa2nAAhHN0"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "4m2yskBQFythfE4irbTIeOgYYfB",
      "id": {
        "kind": "youtube#video",
        "videoId": "IirngItQuVs"
      }
    }
  ]
}


alist = [10,20,30]
for val in alist:
    print(val)


for key,value in ytag.items():
    if key == "etag" and isinstance(value,str):
        print(ytag['etag'])
    elif isinstance(value,list):
        for item in value :   #each item is one dictionary
            if 'etag' in item:
                print(item['etag'])

''' output
1m2yskBQFythfE4irbTIeOgYYfBU1
2m2yskBQFythfE4irbTIeOgYYfBU
3m2yskBQFythfE4irbTIeOgYYfBU
4m2yskBQFythfE4irbTIeOgYYfB
'''