

'''

Write a Python program to display all the files and its accessed time, modified time, change time, and size in bytes with proper formatted output.
'''


import os
import datetime


for file in os.listdir():
    print("size :", file,"bytes")
    print(os.path.getsize(file))
    print("Accessed time :",datetime.datetime.fromtimestamp(os.path.getatime(file)))
    print("Modifed time  :",datetime.datetime.fromtimestamp(os.path.getmtime(file)))
    print("Change time   :",datetime.datetime.fromtimestamp(os.path.getctime(file)))
    print("---------------------")