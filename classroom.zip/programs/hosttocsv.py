import socket

def get_remote_machine_info(remote):  
    try:
        print("IP address: {}".format(socket.gethostbyname(remote))) # www.python.org
    except socket.error as err:
        print("{}: {}".format(remote, err))


with open("hostnames.txt","r") as fobj:
    for host in fobj:
        host = host.strip()
        get_remote_machine_info(host)



# writing the output to the file
import socket
import time
def get_remote_machine_info(remote):

    try:
        filename = time.strftime("host_%d_%b_%Y.csv")
        with open(filename,"a") as fw:
            host = remote
            ipaddress = socket.gethostbyname(remote)
            #print("IP address: {}".format(socket.gethostbyname(remote)))
            fw.write(",".join([host,ipaddress]) + "\n")
    except socket.error as err_msg:
        print("{}: {}".format(remote, err_msg))



with open("hostnames.txt","r") as fobj:
    for host in fobj:
        host = host.strip()
        get_remote_machine_info(host)
