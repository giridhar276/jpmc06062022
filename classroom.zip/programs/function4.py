


# variable length arguments

def display(*args):
    #print(args)
    for val in args:
        print(val)

display(10,20,30,40,12,34,32,3,3,34,90,"unix","python")





def display(**kwargs):
    #print(kwargs)
    for key,value in kwargs.items():
        print(key,value)

display(chap1 =10 , chap2 = 20)







def display(item):
    for val in item:
        print(val)

display([10,20,30,40,])