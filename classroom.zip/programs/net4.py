
'''
If you know the port number of a network service, you can find the service name using the
getservbyport() socket class function from the socket library
'''


import socket
def find_service_name():
    protocolname = 'tcp'
    try:
        for port in [80,25]:
            print("Now reading",port)
            print("Port: %s => service name: %s" %(port, socket.getservbyport(port, protocolname)))
            print("Port: %s => service name: %s" %(53, socket.getservbyport(53, 'udp')))
    except Exception as err:
        pass
find_service_name()