
book = {"chap1":10 ,"chap2":20}
print(book)

# accessing individual key:value
print(book['chap1'])  # 10
print(book['chap2'])  # 20

book = {"chap1":10 ,"chap2":20,"chap1":100}
print(book)


# add new key:value pair
book["chap3"] = 30
book["chap4"] = 40
print(book)



### dipslay keys only

print(book.keys())


## diplsy values
print(book.values())



## display items  
print(book.items())


print(book)
print(book["chap10"])

# method1
print(book.get("chap10"))  # if not existing it returns None
print(book.get("chap1"))   # if existing , it will display the value


#method2

if "chap10" in book:
    print(book["chap10"])
else:
    print("key doesn't exist")



print(book)
#new dictionary
newbook  = {"chap5":50 ,"chap6":60}

# if any object is prefixed with ** .. it becomes dictionary
finalbook = {**book,**newbook}
print(finalbook)



# book is getting updated with key:values of newbook
book.update(newbook)

# newbook is getting udpated with key:values of book
newbook.update(book)




book.pop("chap1")   #chap1:1000 will be removed from dict
print('After pop :', book)


#last key:value will be removed from the dictionary
book.popitem()
print('After pop item :',book)


book.popitem()
print('After pop item :',book)


book.popitem()
print('After pop item :',book)





book = {"chap1":10 ,"chap2":20,"chap3":30}
# display keys
for key in book.keys():
    print(key)
    
    
# display values
for value in book.values():
    print(value)

# display items
for key,value in book.items():
    print(key,value)





print(tuple(book.keys()))
print(list(book.keys()))

print(tuple(book.values()))
print(list(book.values()))





























