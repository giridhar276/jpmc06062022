



import csv
with open("realestate.csv","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        # each line will be in the list format
        print(line[0])
        print(line[1])
        print("-----------")
        
        
        