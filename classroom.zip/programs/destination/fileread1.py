

# method1
# fobj acts as file pointer or file handler or file cursor
with open("customers1.txt","r") as fobj:
    for line in fobj:
        line = line.strip()  # remove white spaces 
        print(line)
        
        
        
        
# method2
# fobj acts as file pointer or file handler or file cursor
# ctrl + A    ctrl + C
# generally used for reading conf files
# returns the string
with open("customers1.txt","r") as fobj:
    print(fobj.read())


#method3    
with open("customers1.txt","r") as fobj:
    print(fobj.readlines()) 



with open("customers1.txt","r") as fobj:
    for line in fobj.readlines() :
        print(line.strip())
        
        
#method4

import csv
with open("customers1.txt","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        # each line will be in the list format
        print(line)




import pandas
df = pandas.read_csv('customers1.txt',header = None)
print(df)



import pandas
df = pandas.read_csv('customers1.txt',header = None)
print(df.head(3))









     

       