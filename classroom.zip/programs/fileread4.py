
'''
write a  program to display all the unique cities and its count from the file


SACRAMENTO - 343 times
RIO LINDA  -  32 times
'''

import csv
citylist = list()
with open("realestate.csv","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        # each line will be in the list format
        city = line[1]
        citylist.append(city)
    # display the output    
    for city in set(citylist):
        print(city.ljust(15), citylist.count(city),"times")








import csv
citydict = dict()
with open("realestate.csv","r") as fobj:
    #convert file object to csv object
    reader = csv.reader(fobj)
    # processing the data
    for line in reader:
        # each line will be in the list format
        city = line[1]
        if city not in citydict:
            citydict[city] = 1
        else:
            citydict[city]+=1
    # display the output    
    for city,count in citydict.items():
        print(city.ljust(15),count,"times")





import pandas
df = pandas.read_csv('realestate.csv')
print(df['city'].unique())
print(df['city'].nunique())


print(df['city'].value_counts())
