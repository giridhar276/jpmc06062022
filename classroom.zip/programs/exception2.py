

import json

try:
    with open("network-config.json","r") as fobj:
        # converting file object to the dictionary using library
        data = json.load(fobj)
        for key,value in data['network'].items():
            if isinstance(value,int):
                print(key.ljust(20),value)
            elif isinstance(value,list):
                print(key)
                print("------")
                for item in value:    #value is list of dictoinaries
                    # item is one dictionary
                    print('ip'.ljust(20),item['ip'])
                    print('wsport'.ljust(20), item['wsPort'])
                    
    output = 1 + "hello"

except FileNotFoundError as err:
    print(err)
    print("File not found")
except TypeError as err:
    print(err)
    print("invalid operation")
except ValueError as err:
    print(err)
    print("Invalid input")
except (IndexError, KeyError,AttributeError) as err:
    print("Invalid index or key defined")
    print(err)
except Exception as err:
    print(err)
